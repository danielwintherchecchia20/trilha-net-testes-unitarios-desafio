using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;

namespace Calculadora.Services
{
    public class ValidacoesString
    {
        public int ContarCaracteres(string texto)
        {
            int num = texto.Length;
            return num;
        }
    }
}